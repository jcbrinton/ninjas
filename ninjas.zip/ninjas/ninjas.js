var gamePiece;
var ninja;
var bullet;
var ninjaArr =[];
var score;
var started;
var reloaded = true;

var test = { 

	//builds game board
	startGame:function() {
	
		background = new component(480, 270, "lightblue", 0, 0);
		gamePiece = new component(50, 50, "Run.png", 0, 0 , "image");
		score = new component("20px", "Consolas", "yellow", 380, 20, "text");
	
		if(started){
			gameArea.stop();
		}
		
		gameArea.start();
		interval = setInterval(addNinja, 100);
         
	}
}

var gameArea = {
    canvas : document.createElement("canvas"),
    //starts game
    start : function() {
    	started=true;
        this.canvas.width = 480;
        this.canvas.height = 270;
        this.context = this.canvas.getContext("2d");
        document.body.insertBefore(this.canvas, document.body.childNodes[0]);
        this.frameNo = 0;
        this.interval = setInterval(updateGameArea, 20);
        window.addEventListener('keydown', function (e) {
            e.preventDefault();
            gameArea.keys = (gameArea.keys || []);
            gameArea.keys[e.keyCode] = (e.type == "keydown");
        })
        window.addEventListener('keyup', function (e) {
            gameArea.keys[e.keyCode] = (e.type == "keydown");            
        })
    },
    //clears board and displays game over screen
    stop : function() {
    	started=false;
        clearInterval(interval);
        clearInterval(this.interval);
        bullet=undefined;
        ninjaArr =[];
        endBackground = new component(480, 270, "black", 0, 0);
        prompt1 = new component("20px", "Consolas", "yellow", 190, 100, "text");
        endBackground.update();    
        prompt1.text="Game Over";
        prompt1.update();
        
    },   
    clear : function() {
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
}

//constructor for a new game component

function component(width, height, color, x, y, type) {

    this.type = type;
    if (type == "image") {
    	this.image = new Image();
    	this.image.src = color;
    }
    this.width = width;
    this.height = height;
    this.speedY = 0;
    this.speedX = 0;
    this.x = x;
    this.y = y;
    
    //updates game component    
    this.update = function() {
        ctx = gameArea.context;
        ctx.save();
    
        if (type == "image") {
        	ctx.drawImage(this.image, 
        	this.x, 
        	this.y,
        	this.width, 
        	this.height);
        }
        else  if (this.type == "text") {
        	ctx.font = this.width + " " + this.height;
        	ctx.fillStyle = color;
        	ctx.fillText(this.text, this.x, this.y);
    	}
    	else{
    		ctx.translate(this.x, this.y);
        	ctx.fillStyle = color;
        	ctx.fillRect(0, 0, this.width, this.height);    
        }    
        ctx.restore();    
    }
    this.newPos = function() {
        this.x += this.speedX;
        this.y -= this.speedY;
    }
    //To see if object hits another object in the game
    this.crashWith = function(otherobj) {
    	var myleft = this.x + (this.width/2);
        var myright = this.x + (this.width*5/8);
        var mytop = this.y + (this.height/4);
        var mybottom = this.y + (this.height*3/4);
        var otherleft = otherobj.x;
        var otherright = otherobj.x + (otherobj.width);
        var othertop = otherobj.y;
        var otherbottom = otherobj.y + (otherobj.height);
        var crash = true;
        if ((mybottom < othertop) || (mytop > otherbottom) || (myright < otherleft) || (myleft > otherright)) {
           crash = false;
        }
        return crash;
    }
}
//updates game board every 20 ms
function updateGameArea() {
    gameArea.clear();
    
    
    if(gamePiece.x<=-10){
    gamePiece.speedX =(gamePiece.speedX*-0);
    } 
    if(gamePiece.x>=440){
	
   		gamePiece.speedX =(gamePiece.speedX*-0);
   	}	
   	if(gamePiece.y<=0){
   		gamePiece.speedY =(gamePiece.speedY*-0);
   	}
   	
   	if(gamePiece.y>=220){
    	gamePiece.speedY =(gamePiece.speedY*-0);
    }
    
    if (gameArea.keys && gameArea.keys[37] &&gamePiece.x>-10 && gamePiece.speedX>-.5) {gamePiece.speedX+=-.3 }
    if (gameArea.keys && gameArea.keys[39]&&gamePiece.x<440 && gamePiece.speedX<.5) {gamePiece.speedX+=.3 }
    if (gameArea.keys && gameArea.keys[38]&&gamePiece.y>0  && gamePiece.speedY<.5) {gamePiece.speedY+=.3 }
    if (gameArea.keys && gameArea.keys[40]&&gamePiece.y<220&& gamePiece.speedY>-.5) {gamePiece.speedY+=-.3 }
    if (gameArea.keys && gameArea.keys[32]) {shoot(); }
    
    background.update();
    gamePiece.newPos();
    gamePiece.update();
   
   
	if(bullet!==undefined){
		
		bullet.newPos();
		bullet.update();
		
		if(bullet.y>300){
			bullet = undefined ;
		}
	}
    
    
 	 for(var j= 0;j<ninjaArr.length;j++){
 	 	ninjaArr[j].speedY = 1;
 	 	ninjaArr[j].newPos();
 	 	ninjaArr[j].update();
 	 	
 	 	if (gamePiece.crashWith(ninjaArr[j])) {
        	gameArea.stop();
        } 
    
     	if(ninjaArr[j]!=undefined){
     		if(ninjaArr[j].y<-100){
     			ninjaArr.splice(j,1);
     		}
     	}
     
     	if(bullet!==undefined){
    		if (bullet.crashWith(ninjaArr[j])) {
        		ninjaArr.splice(j,1);
       			gameArea.frameNo += 1;
       			bullet=undefined;
    		} 
    	}
    	score.text="SCORE: " + gameArea.frameNo;
    	score.update();

     }
}
//creates new ninja components
function addNinja() {
    var xx =Math.floor((Math.random() * 480) + 1);
    
    ninja = new component(30, 30, "Climb.png", xx, 270, "image");
    ninjaArr.push(ninja);
    
}
//creates new bullet components
function shoot() {
    
    if(reloaded===true){
    	bullet = new component(5, 5, "orangered", gamePiece.x + gamePiece.width/2 -5  , gamePiece.y+gamePiece.height/2);
    	bullet.speedY = -10;
    	reloaded =false;
    	setTimeout(function(){ reloaded = true; }, 250);
    }
    
}
